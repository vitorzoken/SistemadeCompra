package com.example.sistemacompras;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private CheckBox cbArroz, cbFeijao, cbCarne, cbLeite, cbRefrigerante;
    private Button btnCalcular;
    private TextView tvTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar componentes
        cbArroz = findViewById(R.id.cbArroz);
        cbFeijao = findViewById(R.id.cbFeijao);
        cbCarne = findViewById(R.id.cbCarne);
        cbLeite = findViewById(R.id.cbLeite);
        cbRefrigerante = findViewById(R.id.cbRefrigerante);
        btnCalcular = findViewById(R.id.btnCalcular);
        tvTotal = findViewById(R.id.tvTotal);

        // Configurar listener do botão
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularTotal();
            }
        });
    }

    private void calcularTotal() {
        double total = 0.0;

        // Verificar quais CheckBox estão marcados e somar seus valores
        if (cbArroz.isChecked()) {
            total += 2.69;
        }
        if (cbFeijao.isChecked()) {
            total += 3.38;
        }
        if (cbCarne.isChecked()) {
            total += 16.70;
        }
        if (cbLeite.isChecked()) {
            total += 2.70;
        }
        if (cbRefrigerante.isChecked()){
            total += 3.00;
        }

        // Atualizar TextView com o total
        tvTotal.setText(String.format("Total: R$ %.2f", total));
    }
}